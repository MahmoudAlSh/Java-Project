
package rent_car_company;

public class User {
    private String firstName, lastName,password, username;
    public User(String firstName, String lastName, String username, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username=username;	
        this.password = password;
        
    }
    public String getFirstName() { return firstName;}
    public String getLastName() {return lastName;}
    public String getPasssword() {return password;}
    public String getUserName() {return username; }
} 
