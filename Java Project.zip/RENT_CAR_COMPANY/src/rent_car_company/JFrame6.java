
package rent_car_company;
import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter; 
import com.sun.glass.events.KeyEvent;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Vector;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class JFrame6 extends javax.swing.JFrame {

   
    public JFrame6() {
        super("Return Car");
        initComponents();
        Image car = new ImageIcon(this.getClass().getResource("/car.png")).getImage();
        this.setIconImage(car);
        Table();
    }
    public void dt(){
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dd = sdf.format(d);
        txtdp6.setText(dd);
        
        
    }
    
    
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    PreparedStatement pst2;
    ResultSet rs;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtcarid6 = new javax.swing.JTextField();
        txtcustid6 = new javax.swing.JTextField();
        txtdate6 = new javax.swing.JTextField();
        txtdp6 = new javax.swing.JTextField();
        txtfine6 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("Car ID:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setText("Customer ID:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setText("Return Date:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setText("Days passed:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel5.setText("Fine:");

        txtcarid6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtcarid6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcarid6ActionPerformed(evt);
            }
        });
        txtcarid6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtcarid6KeyPressed(evt);
            }
        });

        txtcustid6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtcustid6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcustid6ActionPerformed(evt);
            }
        });

        txtdate6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtdate6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdate6ActionPerformed(evt);
            }
        });

        txtdp6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        txtfine6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtfine6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfine6ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton1.setText("Ok");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Customer ID", "Car ID", "Return Date", "Days passed", "Fine"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel6.setText("Enter the Car ID Then Press Enter");

        jButton3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton3.setText("Print Report");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGap(18, 18, 18)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(txtcustid6, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(txtcarid6, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel6)))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(txtdp6))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(txtdate6)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtfine6, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGap(12, 12, 12))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 113, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(46, 46, 46)
                                .addComponent(jButton2)
                                .addGap(109, 109, 109))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3)
                        .addGap(158, 158, 158)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)
                        .addGap(4, 4, 4)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtcarid6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtcustid6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(61, 61, 61)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtdate6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(68, 68, 68)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(txtdp6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtfine6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2))
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)
                        .addGap(25, 25, 25))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane1)))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
  public void Table(){
       
        int n;
        
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");
            pst = con.prepareStatement("SELECT * FROM RETURN");
            ResultSet rs = pst.executeQuery();
            
            ResultSetMetaData rd = rs.getMetaData();
            n = rd.getColumnCount();
            DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
            df.setRowCount(0);
            
            while(rs.next()){
                
                Vector v2 = new Vector();
                
                for(int i = 1 ; i <= n ; i++){
                    
                    v2.add(rs.getString("CAR_ID"));
                    v2.add(rs.getString("CUSTOMER_ID"));
                    v2.add(rs.getString("RETURN_DATE"));
                    v2.add(rs.getString("ELAP"));
                    v2.add(rs.getString("FINE"));

                }
                
                df.addRow(v2);
            }
         
            
        } catch (SQLException ex) {
            Logger.getLogger(JFrame3.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    private void txtcustid6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcustid6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcustid6ActionPerformed

    private void txtdate6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdate6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdate6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    JFrame2 J2 = new JFrame2();
        J2.show();
        dispose();    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtcarid6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcarid6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcarid6ActionPerformed

    private void txtcarid6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcarid6KeyPressed

        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");
                String car_id = txtcarid6.getText();
                
                pst = con.prepareStatement("SELECT CAR_ID,CUSTOMER_ID,DUE_DATE,DATE FROM RENTAL where CAR_ID = ? ");
               
                pst.setString(1, car_id);
                rs = pst.executeQuery();
                
                if(rs.next() == false){
                    JOptionPane.showMessageDialog(this, "Car ID Not Found");
                    
                }
                else{
                    
                    String custid = rs.getString("CUSTOMER_ID");
                    txtcustid6.setText(custid.trim());
                    
                    String dat = rs.getString("DUE_DATE");
                    txtdate6.setText(dat.trim());

                    
                    
                    Date d = new Date();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String dd = sdf.format(d);
                          
                    Date datee = sdf.parse(dat);
                    
                    long timeDiff = Math.abs(d.getTime() - datee.getTime());
                    long daysDiff = TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS);
                    String wwe = String.valueOf(daysDiff);
                    
                    int intdate = Integer.parseInt(wwe);

                   
                    
                    
                    if(intdate > 0 ){
                    txtdp6.setText(String.valueOf(daysDiff));
                    int intdatee = Integer.parseInt(wwe);

                        
                        int fine = intdatee * 100;
                        txtfine6.setText(String.valueOf(fine));
                   }
                    else{
                        txtdp6.setText("0");
                        txtfine6.setText("0");
                    }
                    
                }
               
            }
            catch (SQLException ex) {
                Logger.getLogger(JFrame6.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
                Logger.getLogger(JFrame6.class.getName()).log(Level.SEVERE, null, ex);
            }

            
        }

    }//GEN-LAST:event_txtcarid6KeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        String carid = txtcarid6.getText();
        String cusid = txtcustid6.getText();
        String date = txtdate6.getText();
        String elp = txtdp6.getText();
        String fine = txtfine6.getText();
        
        try {
                
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");
            pst = con.prepareStatement("insert into RETURN(CAR_ID,CUSTOMER_ID,RETURN_DATE,ELAP,FINE)VALUES(?,?,?,?,?) ");
            pst.setString(1, carid);
            pst.setString(2, cusid);
            pst.setString(3, date);
            pst.setString(4, elp);
            pst.setString(5, fine);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Sucssesfully Car Returned And It Is Available");
            
            pst1 = con.prepareStatement("update CARS set AVAILABLE = 'YES' where CAR_ID = ?");
            pst1 .setString(1, carid);
            pst1.executeUpdate();
            
            
            pst2 = con.prepareStatement("delete from RENTAL where CAR_ID = ?");
            pst2.setString(1, carid);
            pst2.executeUpdate();
            
            txtcarid6.setText("");
            txtcustid6.setText("");
            txtdate6.setText("");
            txtdp6.setText("");
            txtfine6.setText("");
        
        }
        catch (SQLException ex) {
            Logger.getLogger(JFrame6.class.getName()).log(Level.SEVERE, null, ex);
        }


       

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        MessageFormat header = new MessageFormat("Late Returns Report");
        MessageFormat footer = new MessageFormat("page{0,number,integer}");
       


        try{
           
            jTable1.print(JTable.PrintMode.NORMAL,header,footer);
            
        
        }
        catch(java.awt.print.PrinterException e){
            System.err.format("Cannot print %s%n", e.getMessage());
            
        }    
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtfine6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfine6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfine6ActionPerformed

    
    

    
    

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrame6().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtcarid6;
    private javax.swing.JTextField txtcustid6;
    private javax.swing.JTextField txtdate6;
    private javax.swing.JTextField txtdp6;
    private javax.swing.JTextField txtfine6;
    // End of variables declaration//GEN-END:variables
}
