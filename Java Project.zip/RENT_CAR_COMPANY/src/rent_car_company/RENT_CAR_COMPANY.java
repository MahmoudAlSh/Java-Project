
package rent_car_company;

import javax.swing.JFrame;

public class RENT_CAR_COMPANY {

    
    public static void main(String[] args) {
        JFrame1 JF =new JFrame1();
        JF.setSize(570, 305);
        JF.setLocationRelativeTo(null);
        JF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JF.setVisible(true);     
    }
    
}
