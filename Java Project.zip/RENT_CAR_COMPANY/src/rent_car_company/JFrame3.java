
package rent_car_company;

import java.sql.*;
import java.awt.Image;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;



public class JFrame3 extends javax.swing.JFrame {
    Connection con;
    Statement st;
    ResultSet rs;
    ResultSet rs1;
    PreparedStatement ss1;
    PreparedStatement ss;
    

   
    public JFrame3() {
        super("Car Registration");
        initComponents();
        Image car = new ImageIcon(this.getClass().getResource("/car.png")).getImage();
        this.setIconImage(car);
        
        dbc();
        Table();
    }
    
    public void dbc(){
        try{
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");
            st = con.createStatement();
            String SQL = "SELECT * FROM CARS";
            rs = st.executeQuery(SQL);
        }
        catch(SQLException err){
            JOptionPane.showMessageDialog(null, err.getMessage());
        }
        
        
    }
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtcarid = new javax.swing.JTextField();
        txtcarmaker = new javax.swing.JTextField();
        txtmodel = new javax.swing.JTextField();
        txtcolor = new javax.swing.JTextField();
        ava = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        txtsearch = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("Car ID:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setText("Car Maker:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setText("Model:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setText("Color:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel5.setText("Available:");

        txtcarid.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        txtcarmaker.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        txtmodel.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        txtcolor.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        ava.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        ava.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "YES", "NO" }));
        ava.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                avaActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Car ID", "Car Maker", "Model", "Color", "Available"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton2.setText("Update");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton4.setText("Return");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        txtsearch.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txtsearch.setText("Search");
        txtsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(txtcarid, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(25, 25, 25))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(txtcarmaker, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtcolor, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                                            .addComponent(txtmodel, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                                            .addComponent(ava, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtsearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(38, 38, 38))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtcarid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtcarmaker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtmodel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtcolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(ava, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(txtsearch))
                        .addGap(18, 18, 18)
                        .addComponent(jButton4)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 451, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        try{
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");
            ss = con.prepareStatement("insert into CARS(CAR_ID,CAR_MAKER,MODEL,COLOR,AVAILABLE)  values(?,?,?,?,?)");
            
            ss.setString(1, txtcarid.getText());
            ss.setString(2, txtcarmaker.getText());
            ss.setString(3, txtmodel.getText());
            ss.setString(4, txtcolor.getText());
            ss.setString(5, ava.getSelectedItem().toString());
           

            
            
            int a = ss.executeUpdate();
            if(a>0){
                JOptionPane.showMessageDialog(null,"Car added Successfully");
            }
            
            Table();
            resetJFrame3();

        }
        catch(SQLException err){
            JOptionPane.showMessageDialog(null, err.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    
    
        void resetJFrame3(){
        txtcarid.setText("");
        txtcarmaker.setText("");
        txtmodel.setText("");
        txtcolor.setText("");
        ava.setSelectedIndex(0);
    }
    
    public void Table(){
       
        int n;
        
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");
            ss = con.prepareStatement("SELECT * FROM CARS");
            ResultSet rs = ss.executeQuery();
            
            ResultSetMetaData rd = rs.getMetaData();
            n = rd.getColumnCount();
            DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
            df.setRowCount(0);
            
            while(rs.next()){
                
                Vector v2 = new Vector();
                
                for(int i = 1 ; i <= n ; i++){
                    
                    v2.add(rs.getString("CAR_ID"));
                    v2.add(rs.getString("CAR_MAKER"));
                    v2.add(rs.getString("MODEL"));
                    v2.add(rs.getString("COLOR"));
                    v2.add(rs.getString("AVAILABLE"));

                }
                
                df.addRow(v2);
            }
         
            
        } catch (SQLException ex) {
            Logger.getLogger(JFrame3.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
 
    
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        JFrame2 J2 = new JFrame2();
        J2.show();
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked

        DefaultTableModel d1 = (DefaultTableModel)jTable1.getModel();
        int SelectIndex = jTable1.getSelectedRow();
        
        txtcarid.setText(d1.getValueAt(SelectIndex, 0).toString());
        txtcarmaker.setText(d1.getValueAt(SelectIndex, 1).toString());
        txtmodel.setText(d1.getValueAt(SelectIndex, 2).toString());
        txtcolor.setText(d1.getValueAt(SelectIndex, 3).toString());
        ava.setSelectedItem(d1.getValueAt(SelectIndex, 4).toString());




    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        DefaultTableModel d1 = (DefaultTableModel)jTable1.getModel();
        int SelectIndex = jTable1.getSelectedRow();
        
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");

            String id = d1.getValueAt(SelectIndex, 0).toString();
            String make = txtcarmaker.getText();
            String mod = txtmodel.getText();
            String col = txtcolor.getText();
            String stat = ava.getSelectedItem().toString();
            
           
            ss = con.prepareStatement("Update CARS SET CAR_MAKER=?,MODEL=?,COLOR=?,AVAILABLE=? WHERE CAR_ID = ?");
         
            ss.setString(1, make);
            ss.setString(2, mod);
            ss.setString(3, col);
            ss.setString(4, stat);
            ss.setString(5, id);

            ss.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Record Updated Successfully");
            Table();
            resetJFrame3();


            
            
            
            
        }
        catch (SQLException ex) {
            Logger.getLogger(JFrame3.class.getName()).log(Level.SEVERE, null, ex);
        }

        


    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        DefaultTableModel d1 = (DefaultTableModel)jTable1.getModel();
        int SelectIndex = jTable1.getSelectedRow();
        
        String id = d1.getValueAt(SelectIndex, 0).toString();
        
        int daialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this record?","Warning",JOptionPane.YES_NO_OPTION);
        if (daialogResult == JOptionPane.YES_OPTION)
        {
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");
                
                ss = con.prepareStatement("delete from CARS where CAR_ID = ?");
                
                ss.setString(1, id);
                ss.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Record Deleted");
                
               Table();
           }
            catch (SQLException ex) {
                Logger.getLogger(JFrame3.class.getName()).log(Level.SEVERE, null, ex);
            }

            
            
        }




    }//GEN-LAST:event_jButton3ActionPerformed

    private void avaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_avaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_avaActionPerformed

    private void txtsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsearchActionPerformed

            
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/Project","Project","123");

                ss = con.prepareStatement("select CAR_ID,CAR_MAKER,MODEL,COLOR,AVAILABLE from CARS where CAR_ID = ?");
                int id = Integer.parseInt(txtcarid.getText());
                ss.setInt(1, id);
                rs = ss.executeQuery();
                if(rs.next() == false){
                    JOptionPane.showMessageDialog(this, "Car Nor Found");
                    resetJFrame3();
                }
                else{
                    txtmodel.setText(rs.getString("MODEL"));
                    txtcarmaker.setText(rs.getString("CAR_MAKER"));
                    txtcolor.setText(rs.getString("COLOR"));
                    ava.setSelectedItem(rs.getString("AVAILABLE"));
                    

                }
            } 
            catch (SQLException ex) {
                Logger.getLogger(JFrame3.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        

    }//GEN-LAST:event_txtsearchActionPerformed


    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrame3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ava;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtcarid;
    private javax.swing.JTextField txtcarmaker;
    private javax.swing.JTextField txtcolor;
    private javax.swing.JTextField txtmodel;
    private javax.swing.JButton txtsearch;
    // End of variables declaration//GEN-END:variables
}
